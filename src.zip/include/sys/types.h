/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef __TYPES_H__
#define __TYPES_H__	1

#ifdef __cplusplus
extern "C" {
#endif

#include <internal/types.h>

#ifdef __cplusplus
}
#endif

#endif

// SPDX-License-Identifier: BSD-3-Clause

#include <errno.h>

int errno;
